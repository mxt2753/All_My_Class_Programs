package store;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.BufferedReader;
//gonna put everything here for the imports 
public interface Saveable 
{
    void save(BufferedWriter bw) throws IOException;
}
