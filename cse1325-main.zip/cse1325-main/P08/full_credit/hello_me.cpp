#include <iostream>

int main() 
{
    std::cout << "Hello, Mary-Rose Tracy!" << std::endl;
}
