package gui;
/*
Name: Mary-Rose Tracy 
ID#:1001852753 
Assignment: P06 Email
TODO: see program comments below
Credit to Prof Rice
*/
public class Elsa {
    public static void main(String[] args) {
        //MainWin mainWin = 
        new MainWin("ELSA");
        //mainWin.setVisible(true);
    }
}
