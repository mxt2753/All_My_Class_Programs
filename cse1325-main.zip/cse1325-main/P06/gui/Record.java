package gui;
public enum Record 
{
    CUSTOMER,
    OPTION,
    COMPUTER,
    ORDER
}
/*
Name: Mary-Rose Tracy 
ID#:1001852753 
Assignment: P06 Email
*/
