/*
Name: Mary-Rose Tracy 
ID#:1001852753 
Assignment: P02 getting an animals/pets w/name type age 
TODO: Do an easy public enum type not anything else
I'm gonna do 6 animals because I'm built different
*/
public enum Type 
{
    Raven, Rabbit, Sheep, Cow, Horse, Dolphin
}
