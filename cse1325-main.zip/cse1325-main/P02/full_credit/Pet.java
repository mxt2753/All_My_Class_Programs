/*
Name: Mary-Rose Tracy 
ID#:1001852753 
Assignment: P02 getting an animals/pets w/name type age 
TODO: specifiy name type age
*/
//let's list the imports just in case
import java.util.Scanner;
import java.util.Arrays;
//need public class Pet
public class Pet 
{

    public Pet(String name, double age, Type type) 
    {
        //let's keep it short & sweet.I noticed all of them are lower case from other code so no Captials.
        this.name = name;
        this.age = age;
        this.type = type;
    }
    //now the String <<Override>>
    
    @Override
    public String toString() 
    {
        return this.name+" is a "+this.type+" of age "+this.age;
    }
    //I know you suppose to put them in the top, but I think it doesn't matter yet. 
    private String name;
    private double age;
    private Type type;
}
