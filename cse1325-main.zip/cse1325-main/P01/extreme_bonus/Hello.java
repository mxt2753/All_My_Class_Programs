/*
Name: Mary-Rose Tracy 
ID#:1001852753 
Assignment: P01 saying hello 
TODO: makng the program automatically say your name without even prompting it 
NOTE: I dont know why but i cant change my name from student. so maybe ill show pngs from other compilers, but it does work!
*/
import java.util.Scanner;
public class Hello
{
	public static void main(String[] args) 
	{
	    String userNameEmailFromTerminal = System.getProperty("user.name");//getProperty from I'm pretty sure form the library
	    //If you do user.Name with a capital N you get "hello null!" interesting
		System.out.println("Hello, "+ userNameEmailFromTerminal + "!");
	}
}
