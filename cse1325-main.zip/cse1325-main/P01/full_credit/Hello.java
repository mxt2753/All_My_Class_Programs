/*
Name: Mary-Rose Tracy 
ID#:1001852753 
Assignment: P01 saying hello 
TODO: makng the program automatically say hello (insert name) straight up without any prompting.
*/
public class Hello 
{
    public static void main(String[] args)
    {
		System.out.println("Hello, Mary-Rose Tracy!"); // OOPS! forgot the ! 
		//you can do that or + "!"either way is fine.
	}
}
