/*
Name: Mary-Rose Tracy 
ID#:1001852753 
Assignment: P06 Email
TODO: see program comments below
Credit to Prof Rice
*/
package gui;

public class Elsa {
    public static void main(String[] args) {
        new MainWin("ELSA");
    }
}

